<?php
// Redirect to the admin panel for now
header('Location: admin/index.html');
exit;
?>